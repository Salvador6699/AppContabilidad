<?php
// backend/index.php

require_once(__DIR__ . '/core/autoload.php');

