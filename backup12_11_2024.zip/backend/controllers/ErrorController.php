<?php
class ErrorController 
{

    public function home()
    {
        echo "error";
    }
}